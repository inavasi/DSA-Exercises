package de.unistuttgart.dsass2017.ex02.p2;

public class Sorter {

	public static <T extends Comparable<T>> void selectionSort(ISimpleList<T> list) {

		// indicates the end of the sorted Part of the List and the beginning of
		// the remaining part of the List
		int sortedRangeEnd = 0;

		// do the search and replace operations until there is only on item left
		// in the unsorted part of the list
		while (sortedRangeEnd < list.size()) {

			// the index of the current smallest item
			int currentSmallestItemIndex = sortedRangeEnd;

			// determine the smallest item in the unsorted part of the List
			for (int i = sortedRangeEnd + 1; i < list.size(); i++) {
				if (list.get(currentSmallestItemIndex).compareTo(list.get(i)) > 0) {
					currentSmallestItemIndex = i;
				}
			}
			list.swap(sortedRangeEnd, currentSmallestItemIndex);
			// Increase the beginning index of the unsorted List
			sortedRangeEnd++;
		}

	}

	public static <T extends Comparable<T>> void bubbleSort(ISimpleList<T> list) {
		// to save the result of the last loop
		boolean swapped;
		do {
			swapped = false;
			for (int i = 0; i < list.size() - 1; i++) {
				// compare the two items and swap the if necessary
				if (list.get(i).compareTo(list.get(i + 1)) > 0) {
					list.swap(i, i + 1);
					swapped = true;
				}
			}
		} while (swapped);
	}

	public static <T extends Comparable<T>> void shakerSort(ISimpleList<T> list) {
		// to save the result of the last loop
		boolean swapped;
		// indicates the index of last Element in the left sorted part of the List (smallest Elements)
		int beginIndex = 0;
		// indicates the index of first Element in the right sorted part of the List (biggest Elements)
		int endIndex = list.size();
		do {
			swapped = false;
			/* compare and swap the biggest Element to the far end of the unsorted List part (from left to right) */
			for (int i = beginIndex; i < endIndex - 1; i++) {
				if (list.get(i).compareTo(list.get(i + 1)) > 0) {
					list.swap(i, i + 1);
					swapped = true;
				}
			}
			endIndex--;
			/* compare and swap the smallest Element to the beginning of the unsorted List part (from right to left) */
			for (int i = endIndex -1; i > beginIndex; i--) {
				if (list.get(i).compareTo(list.get(i - 1)) < 0) {
					list.swap(i, i - 1);
					swapped = true;
				}
			}
			beginIndex++;
		} while (swapped);
	}
}
