package de.unistuttgart.dsass2017.ex02.p2;

public class Sorter {
	
	public static <T extends Comparable<T>> void selectionSort(ISimpleList<T> list) {
	}

	public static <T extends Comparable<T>> void bubbleSort(ISimpleList<T> list) {
	}

	public static <T extends Comparable<T>> void shakerSort(ISimpleList<T> list) {
	}

}
