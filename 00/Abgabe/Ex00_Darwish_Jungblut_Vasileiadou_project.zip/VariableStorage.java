package de.unistuttgart.dsass2017.ex00.p2;

public class VariableStorage<T> implements IVariableStorage<T> {
	/**
	 * @author Hasan Darwish, 3247569
	 * @author Polina Jungblut, 3254837
	 * @author Ina Vasileiadou, 3124938
	 */
	private T variable;

	@Override
	public void set(T var) {
		this.variable = var;
	}

	@Override
	public T get() {
		return this.variable;
	}

}
