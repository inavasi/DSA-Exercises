package de.unistuttgart.dsass2017.ex00.p1;

/**
 * @author Hasan Darwish, 3247569
 * @author Polina Jungblut, 3254837
 * @author Ina Vasileiadou, 3124938
 */
public class Calculator implements ICalculator {

	@Override
	public int add(int a, int b) {
		return a + b;
	}

	@Override
	public int subtract(int a, int b) {
		return a - b;
	}

	@Override
	public int multiply(int a, int b) {
		return a * b;
	}

	@Override
	public int min(int a, int b) {
		return Math.min(a, b);
	}

	@Override
	public int quersumme(int a) {
		int qu_Summe = 0;
		while (a != 0) {
			qu_Summe += a % 10;
			a /= 10;
		}
		return qu_Summe;
	}

}