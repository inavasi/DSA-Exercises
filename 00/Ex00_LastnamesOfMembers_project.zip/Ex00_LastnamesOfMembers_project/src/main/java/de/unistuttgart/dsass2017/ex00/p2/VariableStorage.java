package de.unistuttgart.dsass2017.ex00.p2;

public class VariableStorage<T> implements IVariableStorage<T> {

	

}
