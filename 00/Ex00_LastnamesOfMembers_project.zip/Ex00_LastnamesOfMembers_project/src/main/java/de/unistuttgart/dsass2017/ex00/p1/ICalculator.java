package de.unistuttgart.dsass2017.ex00.p1;

public interface ICalculator {

	/** Returns a+b */
	public int add(int a, int b);
	/** Returns a-b */
	public int subtract(int a, int b);
	/** Returns a*b */
	public int multiply(int a, int b);
	/** Returns minimum of a and b */
	public int min(int a, int b);
	/** Calculate Quersumme */
	public int quersumme(int a);


}
