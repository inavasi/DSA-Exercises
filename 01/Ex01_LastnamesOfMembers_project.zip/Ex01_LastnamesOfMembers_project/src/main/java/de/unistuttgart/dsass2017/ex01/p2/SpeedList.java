package de.unistuttgart.dsass2017.ex01.p2;

public class SpeedList<T> implements ISpeedList<T> {


}
