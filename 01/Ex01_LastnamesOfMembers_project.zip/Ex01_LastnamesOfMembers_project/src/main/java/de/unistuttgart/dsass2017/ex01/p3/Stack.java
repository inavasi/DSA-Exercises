package de.unistuttgart.dsass2017.ex01.p3;


public class Stack<T> implements IStack<T> {
	

}
