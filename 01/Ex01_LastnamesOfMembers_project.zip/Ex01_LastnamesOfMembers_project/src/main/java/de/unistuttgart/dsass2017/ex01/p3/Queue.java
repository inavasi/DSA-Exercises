package de.unistuttgart.dsass2017.ex01.p3;


public class Queue<T> implements IQueue<T> {
	

}
