package de.unistuttgart.dsass2017.ex01.p3;

import static org.junit.Assert.*;

import org.junit.Test;

import de.unistuttgart.dsass2017.ex01.p3.IStack;
import de.unistuttgart.dsass2017.ex01.p3.Stack;

public class StackTest {


}
